import { Layout } from "@/components/layout/Layout";
import { RecipeCard } from "@/components/features/RecipeCard";
import { AdSensePlaceholder } from "@/components/features/AdSensePlaceholder";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import recipeImage from "@assets/generated_images/healthy_recipe_bowl.png";

export default function Recipes() {
  const recipes = [
    {
      title: "Bowl de Quinoa y Aguacate",
      image: recipeImage,
      time: "20 min",
      calories: 450,
      servings: 2,
      tags: ["Vegano", "Sin Gluten"]
    },
    {
      title: "Salmón al Horno con Espárragos",
      image: "https://images.unsplash.com/photo-1467003909585-2f8a7270028d?auto=format&fit=crop&q=80&w=800",
      time: "30 min",
      calories: 520,
      servings: 2,
      tags: ["Alto en Proteína", "Keto"]
    },
    {
      title: "Tostada de Aguacate y Huevo",
      image: "https://images.unsplash.com/photo-1525351484163-7529414395d8?auto=format&fit=crop&q=80&w=800",
      time: "10 min",
      calories: 320,
      servings: 1,
      tags: ["Desayuno", "Vegetariano"]
    },
    {
      title: "Ensalada César con Pollo",
      image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&q=80&w=800",
      time: "15 min",
      calories: 380,
      servings: 1,
      tags: ["Bajo Carb", "Almuerzo"]
    },
    {
      title: "Batido de Proteína y Frutos Rojos",
      image: "https://images.unsplash.com/photo-1553530979-7ee52a2670c4?auto=format&fit=crop&q=80&w=800",
      time: "5 min",
      calories: 250,
      servings: 1,
      tags: ["Snack", "Post-entreno"]
    },
    {
      title: "Wrap de Hummus y Vegetales",
      image: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&q=80&w=800",
      time: "10 min",
      calories: 310,
      servings: 1,
      tags: ["Vegano", "Rápido"]
    },
  ];

  return (
    <Layout>
      <div className="bg-secondary/10 py-12">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="font-heading text-4xl font-bold mb-4">Recetas Saludables</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            Descubre comidas deliciosas que nutren tu cuerpo sin sacrificar el sabor.
          </p>
          <div className="max-w-md mx-auto flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Buscar ingredientes, platos..." className="pl-9 bg-white" />
            </div>
            <Button>Buscar</Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-12">
        <AdSensePlaceholder slot="recipes-top" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {recipes.map((recipe, i) => (
            <RecipeCard key={i} {...recipe} />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button variant="outline" size="lg">Cargar más recetas</Button>
        </div>

        <AdSensePlaceholder slot="recipes-bottom" />
      </div>
    </Layout>
  );
}
