import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calculator, Utensils, Activity } from "lucide-react";
import { Link } from "wouter";
import heroImage from "@assets/generated_images/hero_image_for_nutrition_website.png";
import recipeImage from "@assets/generated_images/healthy_recipe_bowl.png";
import fitnessImage from "@assets/generated_images/fitness_and_wellness.png";
import { RecipeCard } from "@/components/features/RecipeCard";
import { ExerciseCard } from "@/components/features/ExerciseCard";
import { AdSensePlaceholder } from "@/components/features/AdSensePlaceholder";

export default function Home() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative bg-muted/20 overflow-hidden">
        <div className="container mx-auto px-4 py-16 md:py-24 md:px-6 flex flex-col-reverse md:flex-row items-center gap-12">
          <div className="flex-1 space-y-6">
            <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm font-medium text-primary">
              <span className="flex h-2 w-2 rounded-full bg-primary mr-2"></span>
              Tu salud, tu prioridad
            </div>
            <h1 className="font-heading text-4xl md:text-6xl font-bold tracking-tight text-foreground">
              Transforma tu vida con <span className="text-primary">NutriVida</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Descubre el camino hacia un estilo de vida más saludable con nuestras herramientas, recetas y consejos expertos.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/calculadoras">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-lg h-12 px-8">
                  Calcular IMC y Calorías
                </Button>
              </Link>
              <Link href="/recetas">
                <Button size="lg" variant="outline" className="text-lg h-12 px-8 border-primary text-primary hover:bg-primary/10">
                  Ver Recetas
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex-1 relative">
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl rotate-2 hover:rotate-0 transition-transform duration-500">
              <img 
                src={heroImage} 
                alt="Healthy Lifestyle" 
                className="object-cover w-full h-full"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border border-muted hidden md:block">
              <div className="flex items-center gap-3">
                <div className="bg-success/20 p-2 rounded-full">
                  <Activity className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-sm font-bold">Objetivo Diario</p>
                  <p className="text-xs text-muted-foreground">¡Casi lo logras!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <AdSensePlaceholder slot="home-top" />

      {/* Features Grid */}
      <section className="py-16 container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-heading font-bold mb-4">Todo lo que necesitas</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Herramientas completas para acompañarte en cada paso de tu viaje de salud.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-card p-8 rounded-xl shadow-sm border hover:shadow-md transition-shadow flex flex-col items-center text-center">
            <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-6 text-primary">
              <Calculator className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold mb-3">Calculadoras</h3>
            <p className="text-muted-foreground mb-6">
              Conoce tu IMC y tus necesidades calóricas diarias con precisión científica.
            </p>
            <Link href="/calculadoras" className="mt-auto text-primary font-bold flex items-center hover:underline">
              Calcular ahora <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          <div className="bg-card p-8 rounded-xl shadow-sm border hover:shadow-md transition-shadow flex flex-col items-center text-center">
            <div className="h-16 w-16 bg-secondary/10 rounded-full flex items-center justify-center mb-6 text-secondary">
              <Utensils className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold mb-3">Recetas Saludables</h3>
            <p className="text-muted-foreground mb-6">
              Cientos de recetas deliciosas y nutritivas con información calórica detallada.
            </p>
            <Link href="/recetas" className="mt-auto text-secondary font-bold flex items-center hover:underline">
              Explorar Recetas <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          <div className="bg-card p-8 rounded-xl shadow-sm border hover:shadow-md transition-shadow flex flex-col items-center text-center">
            <div className="h-16 w-16 bg-accent/10 rounded-full flex items-center justify-center mb-6 text-accent">
              <Activity className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold mb-3">Fitness y Rutinas</h3>
            <p className="text-muted-foreground mb-6">
              Guías de ejercicios y planes de entrenamiento para todos los niveles.
            </p>
            <Link href="/fitness" className="mt-auto text-accent font-bold flex items-center hover:underline">
              Ver Rutinas <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-heading font-bold">Inspiración Reciente</h2>
            <Link href="/blog">
              <Button variant="ghost">Ver todo</Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <RecipeCard 
              title="Bowl de Quinoa y Aguacate" 
              image={recipeImage} 
              time="20 min" 
              calories={450} 
              servings={2} 
              tags={["Vegano", "Sin Gluten"]} 
            />
            <ExerciseCard 
              title="Yoga Matutino para Energía" 
              description="Una rutina suave de 15 minutos para despertar tu cuerpo y mente." 
              difficulty="Principiante" 
              duration="15 min" 
              image={fitnessImage}
            />
            <RecipeCard 
              title="Batido Verde Detox" 
              image="https://images.unsplash.com/photo-1610970881699-44a5587cabec?auto=format&fit=crop&q=80&w=800" 
              time="5 min" 
              calories={180} 
              servings={1} 
              tags={["Bebida", "Detox"]} 
            />
             <div className="flex flex-col justify-center items-center bg-primary/5 rounded-xl p-6 border border-primary/10 text-center">
                <h3 className="font-heading text-xl font-bold text-primary mb-2">¿Buscas más?</h3>
                <p className="text-sm text-muted-foreground mb-4">Únete a nuestra comunidad y recibe planes personalizados.</p>
                <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">Registrarse Gratis</Button>
             </div>
          </div>
        </div>
      </section>

      <AdSensePlaceholder slot="home-bottom" />
    </Layout>
  );
}
