import { Layout } from "@/components/layout/Layout";
import { AdSensePlaceholder } from "@/components/features/AdSensePlaceholder";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function Blog() {
  const posts = [
    {
      title: "10 Mitos sobre la pérdida de peso que debes dejar de creer",
      excerpt: "Desmentimos las creencias más comunes sobre dietas y ejercicio que podrían estar frenando tu progreso.",
      category: "Nutrición",
      date: "4 Dic, 2023",
      image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=800"
    },
    {
      title: "Cómo mantener la motivación para hacer ejercicio en invierno",
      excerpt: "Consejos prácticos para no abandonar tu rutina cuando el clima se pone difícil.",
      category: "Fitness",
      date: "2 Dic, 2023",
      image: "https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&q=80&w=800"
    },
    {
      title: "Beneficios del ayuno intermitente: ¿Es para ti?",
      excerpt: "Analizamos la ciencia detrás de esta popular estrategia de alimentación y quiénes deberían evitarla.",
      category: "Salud",
      date: "28 Nov, 2023",
      image: "https://images.unsplash.com/photo-1543362906-acfc16c67564?auto=format&fit=crop&q=80&w=800"
    },
    {
      title: "Guía completa de macronutrientes",
      excerpt: "Aprende a balancear proteínas, carbohidratos y grasas para optimizar tu salud y rendimiento.",
      category: "Nutrición",
      date: "25 Nov, 2023",
      image: "https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&q=80&w=800"
    }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12 md:px-6">
        <h1 className="font-heading text-4xl font-bold mb-8 text-center">Blog de Salud</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {posts.map((post, i) => (
              <Card key={i} className="overflow-hidden flex flex-col md:flex-row hover:shadow-md transition-shadow">
                <div className="md:w-1/3 h-48 md:h-auto">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 p-6 flex flex-col">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="text-xs font-normal">{post.category}</Badge>
                    <span className="text-xs text-muted-foreground">{post.date}</span>
                  </div>
                  <h2 className="text-xl font-bold font-heading mb-2 hover:text-primary cursor-pointer">{post.title}</h2>
                  <p className="text-muted-foreground text-sm mb-4 flex-1">{post.excerpt}</p>
                  <Button variant="link" className="p-0 h-auto self-start text-primary">Leer más</Button>
                </div>
              </Card>
            ))}
            <div className="text-center pt-4">
               <Button variant="outline">Ver artículos anteriores</Button>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-muted/20 p-6 rounded-xl">
              <h3 className="font-bold mb-4">Suscríbete al Newsletter</h3>
              <p className="text-sm text-muted-foreground mb-4">Recibe los mejores consejos de salud semanalmente.</p>
              <div className="space-y-2">
                <input type="email" placeholder="Tu email" className="w-full p-2 rounded border text-sm" />
                <Button className="w-full bg-primary hover:bg-primary/90">Suscribirse</Button>
              </div>
            </div>
            <AdSensePlaceholder slot="blog-sidebar" />
          </div>
        </div>
      </div>
    </Layout>
  );
}
