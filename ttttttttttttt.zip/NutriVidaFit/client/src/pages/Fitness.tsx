import { Layout } from "@/components/layout/Layout";
import { ExerciseCard } from "@/components/features/ExerciseCard";
import { AdSensePlaceholder } from "@/components/features/AdSensePlaceholder";
import fitnessImage from "@assets/generated_images/fitness_and_wellness.png";

export default function Fitness() {
  const exercises = [
    {
      title: "Yoga Matutino para Energía",
      description: "Una rutina suave de 15 minutos para despertar tu cuerpo y mente, enfocada en la respiración y la flexibilidad.",
      difficulty: "Principiante" as const,
      duration: "15 min",
      image: fitnessImage,
    },
    {
      title: "HIIT Cardio en Casa",
      description: "Entrenamiento de alta intensidad por intervalos para quemar calorías rápidamente sin necesidad de equipo.",
      difficulty: "Intermedio" as const,
      duration: "25 min",
      image: "https://images.unsplash.com/photo-1517963879466-e9b5ce382d5d?auto=format&fit=crop&q=80&w=800",
    },
    {
      title: "Fuerza Total (Full Body)",
      description: "Rutina completa para fortalecer todos los grupos musculares principales utilizando mancuernas o botellas de agua.",
      difficulty: "Avanzado" as const,
      duration: "45 min",
      image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=800",
    },
    {
      title: "Estiramientos para Oficina",
      description: "Ejercicios simples para aliviar la tensión de estar sentado todo el día. Perfecto para pausas activas.",
      difficulty: "Principiante" as const,
      duration: "10 min",
      image: "https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&q=80&w=800",
    },
  ];

  return (
    <Layout>
      <div className="bg-accent/10 py-12">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="font-heading text-4xl font-bold mb-4">Fitness y Bienestar</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Rutinas diseñadas por expertos para ayudarte a alcanzar tus metas de fitness, desde cualquier lugar.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
            {exercises.map((exercise, i) => (
              <ExerciseCard key={i} {...exercise} />
            ))}
          </div>
          
          <div className="space-y-8">
            <div className="bg-card border p-6 rounded-xl shadow-sm">
              <h3 className="font-bold text-lg mb-4">Categorías</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="flex justify-between hover:text-primary"><span>Cardio</span> <span className="text-muted-foreground">12</span></a></li>
                <li><a href="#" className="flex justify-between hover:text-primary"><span>Fuerza</span> <span className="text-muted-foreground">8</span></a></li>
                <li><a href="#" className="flex justify-between hover:text-primary"><span>Yoga</span> <span className="text-muted-foreground">15</span></a></li>
                <li><a href="#" className="flex justify-between hover:text-primary"><span>Pilates</span> <span className="text-muted-foreground">6</span></a></li>
                <li><a href="#" className="flex justify-between hover:text-primary"><span>Estiramientos</span> <span className="text-muted-foreground">10</span></a></li>
              </ul>
            </div>
            <AdSensePlaceholder slot="fitness-sidebar" />
          </div>
        </div>
      </div>
    </Layout>
  );
}
