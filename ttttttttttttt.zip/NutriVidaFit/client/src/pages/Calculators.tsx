import { Layout } from "@/components/layout/Layout";
import { BMICalculator } from "@/components/features/BMICalculator";
import { CalorieCalculator } from "@/components/features/CalorieCalculator";
import { AdSensePlaceholder } from "@/components/features/AdSensePlaceholder";

export default function Calculators() {
  return (
    <Layout>
      <div className="bg-primary/10 py-12">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="font-heading text-4xl font-bold mb-4">Calculadoras de Salud</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Utiliza nuestras herramientas científicas para entender mejor tu cuerpo y planificar tus objetivos.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center">
                <span className="bg-primary/20 text-primary p-2 rounded-lg mr-3">1</span>
                Calculadora de IMC
              </h2>
              <p className="text-muted-foreground mb-6">
                El Índice de Masa Corporal (IMC) es una medida simple de peso para la talla que se usa comúnmente para clasificar el bajo peso, el sobrepeso y la obesidad.
              </p>
              <BMICalculator />
            </div>
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
              <h3 className="font-bold text-blue-800 mb-2">¿Qué significan los resultados?</h3>
              <ul className="list-disc list-inside text-sm text-blue-700 space-y-1">
                <li><strong>Bajo peso:</strong> IMC menor a 18.5</li>
                <li><strong>Peso normal:</strong> IMC de 18.5 a 24.9</li>
                <li><strong>Sobrepeso:</strong> IMC de 25 a 29.9</li>
                <li><strong>Obesidad:</strong> IMC de 30 o más</li>
              </ul>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center">
                <span className="bg-secondary/20 text-secondary p-2 rounded-lg mr-3">2</span>
                Calculadora de Calorías
              </h2>
              <p className="text-muted-foreground mb-6">
                Estima cuántas calorías quemas en un día promedio y cuántas necesitas para mantener, perder o ganar peso.
              </p>
              <CalorieCalculator />
            </div>
             <AdSensePlaceholder slot="calculator-sidebar" />
          </div>
        </div>
      </div>
    </Layout>
  );
}
