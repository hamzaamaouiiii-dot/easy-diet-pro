import { Leaf, Facebook, Twitter, Instagram, Youtube } from "lucide-react";
import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-muted/50 border-t">
      <div className="container mx-auto px-4 py-12 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-primary" />
              <span className="font-heading text-xl font-bold text-primary">NutriVida</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Tu compañero diario para una vida más saludable y equilibrada.
            </p>
          </div>

          <div>
            <h3 className="font-heading font-semibold mb-4">Contenido</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/recetas" className="hover:text-primary transition-colors">Recetas Saludables</Link></li>
              <li><Link href="/fitness" className="hover:text-primary transition-colors">Rutinas de Ejercicio</Link></li>
              <li><Link href="/calculadoras" className="hover:text-primary transition-colors">Calculadoras de Salud</Link></li>
              <li><Link href="/blog" className="hover:text-primary transition-colors">Blog de Nutrición</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-semibold mb-4">Legal</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Política de Privacidad</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Términos de Uso</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Cookies</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-semibold mb-4">Síguenos</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} NutriVida. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
