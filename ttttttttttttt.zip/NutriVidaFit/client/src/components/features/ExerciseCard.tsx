import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ExerciseCardProps {
  title: string;
  description: string;
  difficulty: "Principiante" | "Intermedio" | "Avanzado";
  duration: string;
  image: string;
}

export function ExerciseCard({ title, description, difficulty, duration, image }: ExerciseCardProps) {
  const difficultyColor = {
    "Principiante": "text-success",
    "Intermedio": "text-accent",
    "Avanzado": "text-destructive"
  };

  return (
    <Card className="flex flex-col h-full overflow-hidden hover:shadow-md transition-shadow">
      <div className="aspect-video w-full overflow-hidden bg-muted">
        <img src={image} alt={title} className="w-full h-full object-cover" />
      </div>
      <CardHeader className="p-4">
        <div className="flex justify-between items-start mb-2">
          <span className={`text-xs font-bold uppercase tracking-wider ${difficultyColor[difficulty]}`}>
            {difficulty}
          </span>
          <span className="text-xs text-muted-foreground">{duration}</span>
        </div>
        <CardTitle className="font-heading text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0 flex-1 flex flex-col">
        <p className="text-sm text-muted-foreground mb-4 flex-1 line-clamp-3">
          {description}
        </p>
        <Button variant="outline" className="w-full group">
          Ver Rutina
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </CardContent>
    </Card>
  );
}
