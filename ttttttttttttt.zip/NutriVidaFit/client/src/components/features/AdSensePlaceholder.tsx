export function AdSensePlaceholder({ slot, format = "auto", responsive = true }: { slot?: string, format?: string, responsive?: boolean }) {
  return (
    <div className="w-full my-8 bg-muted/30 border-2 border-dashed border-muted rounded-lg flex flex-col items-center justify-center min-h-[150px] p-4 text-center">
      <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Publicidad</span>
      <div className="text-sm text-muted-foreground">Google AdSense Placeholder</div>
      {slot && <div className="text-xs text-muted-foreground/50 mt-1">Slot ID: {slot}</div>}
    </div>
  );
}
