import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export function BMICalculator() {
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [bmi, setBmi] = useState<number | null>(null);
  const [category, setCategory] = useState("");

  const calculateBMI = () => {
    const h = parseFloat(height) / 100; // cm to m
    const w = parseFloat(weight);

    if (h > 0 && w > 0) {
      const bmiValue = w / (h * h);
      setBmi(parseFloat(bmiValue.toFixed(1)));

      if (bmiValue < 18.5) setCategory("Bajo peso");
      else if (bmiValue < 25) setCategory("Peso normal");
      else if (bmiValue < 30) setCategory("Sobrepeso");
      else setCategory("Obesidad");
    }
  };

  return (
    <Card className="w-full shadow-lg border-primary/10">
      <CardHeader className="bg-primary/5 pb-4">
        <CardTitle className="text-primary font-heading">Calculadora de IMC</CardTitle>
        <CardDescription>Calcula tu Índice de Masa Corporal</CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div className="space-y-2">
          <Label htmlFor="height">Altura (cm)</Label>
          <Input
            id="height"
            type="number"
            placeholder="170"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            className="border-primary/20 focus:border-primary"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="weight">Peso (kg)</Label>
          <Input
            id="weight"
            type="number"
            placeholder="70"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="border-primary/20 focus:border-primary"
          />
        </div>
        <Button onClick={calculateBMI} className="w-full bg-secondary hover:bg-secondary/90 text-white">
          Calcular
        </Button>

        {bmi !== null && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-4 bg-primary/10 rounded-lg text-center"
          >
            <p className="text-sm text-muted-foreground">Tu IMC es</p>
            <p className="text-4xl font-bold text-primary my-2">{bmi}</p>
            <p className={`text-lg font-semibold ${
              category === "Peso normal" ? "text-success" : "text-accent"
            }`}>
              {category}
            </p>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
