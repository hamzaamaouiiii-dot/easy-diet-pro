import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Flame, Users } from "lucide-react";

interface RecipeCardProps {
  title: string;
  image: string;
  time: string;
  calories: number;
  servings: number;
  tags: string[];
}

export function RecipeCard({ title, image, time, calories, servings, tags }: RecipeCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 border-none shadow-md group">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60" />
        <div className="absolute bottom-3 left-3 flex flex-wrap gap-1">
          {tags.map(tag => (
            <Badge key={tag} variant="secondary" className="bg-white/90 text-black hover:bg-white text-xs backdrop-blur-sm">
              {tag}
            </Badge>
          ))}
        </div>
      </div>
      <CardHeader className="p-4 pb-2">
        <h3 className="font-heading font-bold text-lg leading-tight group-hover:text-primary transition-colors">
          {title}
        </h3>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="flex items-center justify-between text-sm text-muted-foreground mt-2">
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{time}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Flame className="w-4 h-4 text-accent" />
            <span>{calories} kcal</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="w-4 h-4" />
            <span>{servings}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
