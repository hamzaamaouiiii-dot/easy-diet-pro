import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { motion } from "framer-motion";

export function CalorieCalculator() {
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [activity, setActivity] = useState("1.2");
  const [calories, setCalories] = useState<number | null>(null);

  const calculateCalories = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height);
    const a = parseFloat(age);
    const act = parseFloat(activity);

    if (w && h && a) {
      // Mifflin-St Jeor Equation
      let bmr = (10 * w) + (6.25 * h) - (5 * a);
      bmr += gender === "male" ? 5 : -161;
      
      const tdee = Math.round(bmr * act);
      setCalories(tdee);
    }
  };

  return (
    <Card className="w-full shadow-lg border-secondary/10">
      <CardHeader className="bg-secondary/5 pb-4">
        <CardTitle className="text-secondary font-heading">Calculadora de Calorías</CardTitle>
        <CardDescription>Estima tus necesidades calóricas diarias</CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div className="space-y-2">
          <Label>Género</Label>
          <RadioGroup defaultValue="male" onValueChange={setGender} className="flex space-x-4">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">Hombre</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">Mujer</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="cal-age">Edad</Label>
            <Input id="cal-age" type="number" value={age} onChange={(e) => setAge(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cal-weight">Peso (kg)</Label>
            <Input id="cal-weight" type="number" value={weight} onChange={(e) => setWeight(e.target.value)} />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="cal-height">Altura (cm)</Label>
          <Input id="cal-height" type="number" value={height} onChange={(e) => setHeight(e.target.value)} />
        </div>

        <div className="space-y-2">
          <Label>Nivel de Actividad</Label>
          <Select value={activity} onValueChange={setActivity}>
            <SelectTrigger>
              <SelectValue placeholder="Selecciona nivel de actividad" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1.2">Sedentario (Poco o nada de ejercicio)</SelectItem>
              <SelectItem value="1.375">Ligero (Ejercicio 1-3 días/sem)</SelectItem>
              <SelectItem value="1.55">Moderado (Ejercicio 3-5 días/sem)</SelectItem>
              <SelectItem value="1.725">Activo (Ejercicio 6-7 días/sem)</SelectItem>
              <SelectItem value="1.9">Muy Activo (Trabajo físico/Atleta)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button onClick={calculateCalories} className="w-full bg-primary hover:bg-primary/90">
          Calcular Calorías
        </Button>

        {calories && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-4 p-4 bg-secondary/10 rounded-lg text-center space-y-2"
          >
            <p className="text-sm text-muted-foreground">Calorías de mantenimiento</p>
            <p className="text-4xl font-bold text-secondary">{calories} kcal</p>
            <div className="pt-2 text-xs text-muted-foreground grid grid-cols-3 gap-2 border-t border-secondary/20 mt-2">
              <div>
                <span className="block font-bold text-primary">Pérdida</span>
                {calories - 500}
              </div>
              <div>
                <span className="block font-bold text-secondary">Mantener</span>
                {calories}
              </div>
              <div>
                <span className="block font-bold text-accent">Ganancia</span>
                {calories + 500}
              </div>
            </div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
